
public class ChessDRAFT {

	public ChessDRAFT(){
		
	}
	public static void main(String[] args) {
		new Chess();
	}

}
