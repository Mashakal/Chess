import java.util.ArrayList;


public class Liststuff {
	
	static int[] array0;
	static ArrayList<Integer> array1;
	
	public static void main(String[] args){
		
		array0 = new int[10];
		array1 = new ArrayList<Integer>();
		
		array1.add(1);
		array1.add(2);
		array1.add(45);
		array1.clear();
		
	}
	
	

}
